The Windows executable is created here after running BUILD_WINDOWS.bat from the PROJECT SOURCE CODE folder.
